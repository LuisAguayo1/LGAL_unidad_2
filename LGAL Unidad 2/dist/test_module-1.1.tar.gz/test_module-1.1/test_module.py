import math


def area(y: float) -> float:
    area = 4.0 * math.pi * y ** 2
    return area


def volumen(y: float) -> float:
    vol = 1 / 3 * math.pi * y ** 3
    return vol
